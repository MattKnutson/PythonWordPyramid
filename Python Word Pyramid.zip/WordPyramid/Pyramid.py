# Programmer: Matt Knutson #
# Date: 05/02/2024 #


##########################################
# Build a function to decode a text file #
##########################################

def decode_file(text_file):

    # Open the text file as "read" only #

    with open(text_file, "r") as file:

        # Add the lines of the file to the "file_lines" variable #

        file_lines = file.readlines()

    ###########################################################
    # Initialize an EMPTY list to store the text file's words #
    ###########################################################

    file_words = []

    ##################################################################################
    # Create a NULL placeholder for each element in the list (up to 10,000 elements) #
    ##################################################################################

    for x in range(10000):

        file_words.append('')

    ##############################################
    # Use a FOR loop to iterate through the file #
    ##############################################

    for line in file_lines:

        # Split the line using white-space and assign the variable "number" with the first index of the line #

        number = int(line.split()[0])

        # Determine whether the "number" represents the last element in a pyramid step #

        for x in range(10000):

            # IF the number corresponds to the last entry on the next pyramid step #

            if number == (int((x * x + x) / 2)):

                # Assign the index space with the word from the current entry #

                file_words[x] = line.split()[1]

                break

        #################################################
        # Start an empty list to hold the final message #
        #################################################

        final_message = ""

        ########################################################
        # Loop through the list of words to find valid entries #
        ########################################################

        for x in file_words:

            # IF the entry is NOT empty (the entry IS a step on the pyramid) #

            if x != '':

                # ADD the word to the final message #

                final_message = final_message + x + " "

    ############################
    # RETURN the final message #
    ############################

    return final_message


##########################
# Initialize a file path #
##########################

file_path = "Word_Pyramid.txt"

###############################################################
# CALL the "decode_file" method using the specified file path #
###############################################################

decoded_message = decode_file(file_path)

# PRINT the decoded message #

print(decoded_message)




